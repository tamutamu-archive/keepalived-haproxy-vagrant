package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import java.net.InetAddress;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.net.UnknownHostException; 

@RestController
@RequestMapping("/api/v1/test")
public class TestController {

    @RequestMapping(method = RequestMethod.GET)
    public String getTest() {
        try{
            String hostName = InetAddress.getLocalHost().getHostName();
            DateFormat format = new SimpleDateFormat("yyyy MM dd hh:mm:ss.SSS");
            String now = format.format(new Date());
            return String.format("hostName:%1s,Date:%2s", hostName, now);
	} catch(UnknownHostException e) {
            e.printStackTrace();
	}

	return "Error"; 
    }
}
